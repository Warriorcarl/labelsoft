电脑操作系统要求：
System Requirements:
WinXP,Vista,Win7,Win8,Win8.1,Win10,Win11

WinXP要求已安装.NET Framework 2.0版本。
WinXP requires that the .NET Framework 2.0 has been installed.

软件为绿色版本，将本压缩包解压缩到文件夹后运行LabelSoft.exe即可。
Please unzip the compressed package to a folder and run LabelSoft.exe.

技术支持：
工作日9点30分到17点30分
电话号码：0755-23213336
其它时间请访问我们的网站获取更多的技术支持信息或者发送电子邮件地址到: support@zmin.com.cn

Technical Support:
9:30 to 17:30 on weekdays
Phone number: +86 755 2321 3336
At other times, please visit our website for more technical support information or send an email address to: support@zmin.com.cn

深圳致明兴科技有限公司
ZMIN Technologies Co.,Ltd.
http://www.zmin.com.cn
http://www.zmin.com.cn/en/